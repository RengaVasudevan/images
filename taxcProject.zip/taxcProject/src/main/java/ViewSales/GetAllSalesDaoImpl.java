package ViewSales;

import java.sql.Types;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;


@Component
public class GetAllSalesDaoImpl extends JdbcDaoSupport implements ITestDao {

	final static Logger logger = Logger.getLogger(ConnectionManager.class);      
	@Autowired
	public GetAllSalesDaoImpl(DataSource datasource) 
	{
		 setDataSource(datasource);
	}

	public List<ViewAllSalesBean> getAllTests() throws Exception {
		// TODO Auto-generated method stub
		List<ViewAllSalesBean> testList = null;

		testList = getJdbcTemplate().query("select * from salestb",
				new Object[] {}, new TestRowMapper());
       logger.info("I'm here");
System.out.println(testList);
Iterator itr =testList.iterator();
for(ViewAllSalesBean b:testList)
{
	System.out.println(b.toString());
}
		return testList;
	}



}