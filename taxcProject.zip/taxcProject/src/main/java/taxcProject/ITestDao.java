package taxcProject;

import java.util.List;



public interface ITestDao {
	
	public List<ViewAllSalesBean> getAllTests() throws Exception;
	
	


}
