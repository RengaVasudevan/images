package taxcProject;

public class ViewAllSalesBean 
{
int sid,qua;
public int getSid() {
	return sid;
}


public void setSid(int sid) {
	this.sid = sid;
}
float price,tax;
String act,comname;
public ViewAllSalesBean()
{
	}
ViewAllSalesBean(int sid,String cn,int q,String at,float pr,float tx)
{
	this.sid=sid;
	comname=cn;
	qua=q;
	act=at;
	price=pr;
	tax=tx;
	
}


public int getQua() {
	return qua;
}
public void setQua(int qua) {
	this.qua = qua;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public float getTax() {
	return tax;
}
public void setTax(float tax) {
	this.tax = tax;
}
public String getAct() {
	return act;
}
public void setAct(String act) {
	this.act = act;
}
public String getComname() {
	return comname;
}
public void setComname(String comname) {
	this.comname = comname;
}

}
