package taxcProject;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class LoginDAO 
{
	static Connection con=null;
   static ResultSet rs,rs1;
  static  LoginBean lbean=new LoginBean();
	static Statement st=null;
	static PreparedStatement pst=null;
	 
public static int validateShopkeeper(LoginBean lbean)
{
	int i=0;
	String sqlst="",name="",email=""; 
    int comac=0;
	try
	{
		
		
		
	     con=ConnectionManager.getConnection();
		   st =con.createStatement();
	   
      
        sqlst ="SELECT name,comacc,email from shopktb WHERE sid="+lbean.getSid();
		
		 rs = st.executeQuery(sqlst);
		 while(rs.next())
			{
			  name=rs.getString("name");
		      comac  = rs.getInt("comacc");
		      email=rs.getString("email");
		    }
		
		 
			 
		 rs=null;
		 sqlst ="SELECT name,comacc from shopktb WHERE sid="+lbean.getSid();
			
		 rs1 = st.executeQuery(sqlst);
		 
		if(lbean.getEmail().equals(email))
		{
		if(comac==(lbean.getComacc()))
		{	
			
			    st =con.createStatement();
				sqlst ="SELECT name,bankacc from shopktb WHERE sid="+lbean.getSid();
				 rs = st.executeQuery(sqlst);
				while(rs.next())
				{
			     
					lbean.setName(rs.getString("name"));
			        lbean.setBankacc(rs.getInt("bankacc"));
			    }
			
				
				sqlst ="SELECT balance from banktb WHERE bankacc="+lbean.getBankacc();
				 rs = st.executeQuery(sqlst);
				while(rs.next())
				{
			     lbean.setBal(rs.getInt("balance"));
			    }
				i=1;
			
	    }
		
		else
		{
		i=3;	
		}
		
		}
		else
		{
		i=2;	
	    }
	
}
catch(Exception e)
	{
		
		
	}
	
	
	
return i;
}
}
