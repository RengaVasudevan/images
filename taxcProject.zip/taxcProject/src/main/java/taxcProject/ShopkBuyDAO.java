package taxcProject;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;




public class ShopkBuyDAO 
{
	static Connection con=null;
	   static ResultSet rs,rs1;
	  static  ShopkBuyBean sbean=new ShopkBuyBean();
		static Statement st=null;
		final static Logger logger = Logger.getLogger(ShopkBuyDAO.class);      
	public static int shopkBuys(ShopkBuyBean sbean)
	{
		int i=0,price,comacc=0,bankacc=0,quanc=0,bal=0;
		String sqlst="";
		try
		{
			con=ConnectionManager.getConnection();
			st =con.createStatement();
		    sqlst ="SELECT name from shopktb WHERE sid="+sbean.getSid();
			
			ResultSet rs = st.executeQuery(sqlst);
			
		   price=(sbean.getQua())*10;
			System.out.println("\nCalculated Price:"+price);
			con=ConnectionManager.getConnection();
			System.out.println("DB Connected !");
		
		 st =con.createStatement();
		sqlst ="SELECT comacc,bankacc from shopktb WHERE sid="+sbean.getSid();
		 rs = st.executeQuery(sqlst);
		while(rs.next())
		{
	     comacc  = rs.getInt("comacc");
	     bankacc=rs.getInt("bankacc");
	    }
		//System.out.println(comacc+bankacc);
		
		
		
		sqlst ="SELECT balance from banktb WHERE bankacc="+bankacc;
		 rs = st.executeQuery(sqlst);
		while(rs.next())
		{
	     bal = rs.getInt("balance");
	    }
		logger.info("\nInspection going on....");
		if(price<=bal)
		{
			
		sqlst="";
		sqlst ="SELECT "+sbean.getComtdy()+ " from comtb WHERE comacc="+comacc;
	     rs = st.executeQuery(sqlst);
		while(rs.next())
		{
	     quanc  = rs.getInt(sbean.getComtdy());
	    }
		
		
		sqlst="";
		sqlst = "UPDATE comtb " +"SET "+sbean.getComtdy()+" = "+ (quanc+sbean.getQua())+" WHERE comacc="+comacc;
        st.executeUpdate(sqlst);
        sqlst="";
		sqlst = "INSERT INTO salestb VALUES("+sbean.getSid()+",'"+sbean.getComtdy()+"',"+sbean.getQua()+",'Buy',"+price+","+((price*10)/100)+")";
	
        st.executeUpdate(sqlst);
        sqlst="";
        sqlst = "UPDATE banktb SET balance = "+ (bal-price)+" WHERE bankacc="+bankacc;
        st.executeUpdate(sqlst);
        logger.info("\nTransaction commited !\n");
        logger.info("Commodity "+sbean.getComtdy()+" of quantity "+sbean.getQua()+" has been bought succesfully by shopkeeper "+sbean.getSid());
		i=1;
		}
		else
		{
			
			i=2;
			logger.warn("You dont have enough balance");
			
		}
			
		}
	
		catch(SQLException e)
	{
		e.printStackTrace();
	} 
		
		
		finally
		{
		
		try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			
		}
		
		
		
		
		return i;
	}

}
