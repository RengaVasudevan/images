
package taxcProject;


public class ShowShopkBean 
{
	
private String act,name,comtdy,bankname,ifsc;





private int sid,quanc,qua,comacc,bankacc,bal,com1,com2,com3;
float price,tax;
public ShowShopkBean (int s,String c,int q,String a,float p,float t)
{
	sid=s;
	comtdy=c;
	qua=q;
	price=p;
	act=a;
	tax=t;
}
public ShowShopkBean()
{
	

}

public String getBankname() {
	return bankname;
}
public void setBankname(String bankname) {
	this.bankname = bankname;
}
public String getIfsc() {
	return ifsc;
}
public void setIfsc(String ifsc) {
	this.ifsc = ifsc;
}


public float getPrice() {
	return price;
}


public void setPrice(float price) {
	this.price = price;
}


public float getTax() {
	return tax;
}


public void setTax(float tax) {
	this.tax = tax;
}


public int getCom1() {
	return com1;
}
public void setCom1(int com1) {
	this.com1 = com1;
}
public int getCom2() {
	return com2;
}
public void setCom2(int com2) {
	this.com2 = com2;
}
public int getCom3() {
	return com3;
}
public void setCom3(int com3) {
	this.com3 = com3;
}



public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public int getSid() {
	return sid;
	
}
public void setSid(int sid) {
	this.sid = sid;
}
public int getQuanc() {
	return quanc;
}
public void setQuanc(int quanc) {
	this.quanc = quanc;
}
public int getQua() {
	return qua;
}
public void setQua(int qua) {
	this.qua = qua;
}
public int getComacc() {
	return comacc;
}
public void setComacc(int comacc) {
	this.comacc = comacc;
}

public int getBankacc() {
	return bankacc;
}
public void setBankacc(int bankacc) {
	this.bankacc = bankacc;
}
public int getBal() {
	return bal;
}
public void setBal(int bal) {
	this.bal = bal;
}
public String getAct() {
	return act;
}


public void setAct(String act) {
	this.act = act;
}


public String getComtdy() {
	return comtdy;
}


public void setComtdy(String comtdy) {
	this.comtdy = comtdy;
}



}
