drop table banktb;
create table banktb(bankacc int,balance int,primary key(bankacc)); 
phone_number integer not null check (phone_number between 0 and 9999999999)

create table salestb(sid int,comname varchar(10),quant int,act varchar(10),price int,tax_amount int);
create table shopktb(sid int,name varchar(30),comacc int,bankacc int,primary key(sid));
create table comtb(comacc int,com1 int,com2 int,com3 int,primary key(comacc));
update comtb set com1=15 where comacc=25;
create table ittb(dptid int,name varchar(20),pas varchar(15),primary key(dptid));
insert into banktb values(4321,10000);
insert into ittb values(1001,'Sekar','12345');
drop table ittb;
ALTER TABLE salestb DROP txnid;
select * from shopktb order by sid;
select * from shopktb order by comacc;
select * from shopktb order by bankacc
select * from comtb order by comacc;
select * from banktb order by bankacc;
select * from salestb order by sid;
select * from shopktb order by comacc

create table banktb(bankacc int,balance int,primary key(bankacc)); 
drop table banktb;
select * from ittb;
alter table banktb drop column ifsc
ALTER TABLE banktb ADD ifsc varchar(11);
ALTER TABLE shopktb ADD email varchar(30);
delete from banktb where bankacc=1569874; 
delete from comtb where comacc=24; 6 38 67 sid  76 58 36
ALTER TABLE banktb ALTER COLUMN ifsc varchar(11);
DELETE FROM shopktb WHERE email is null;
DELETE FROM salestb WHERE quant=1;
DELETE FROM banktb WHERE balance=54;
DELETE FROM comtb WHERE comacc =98;
insert into comtb values(98,0,0,0);
insert into banktb values(1254784,95000,'Bank of India','BOI2451241P');


ALTER TABLE banktb ALTER COLUMN bankname varchar(30) not null;

ALTER TABLE banktb ADD COLUMN banknam varchar(30);
UPDATE banktb SET =MY_COLUMN;
ALTER TABLE MY_TABLE DROP COLUMN MY_COLUMN;
RENAME COLUMN MY_TABLE.NEW_COLUMN TO MY_COLUMN;

1245741
select * from banktb 
ALTER TABLE banktb ADD bankn varchar(30);
UPDATE banktb SET bankn=bankname;

create table banktb(bankacc int,bankname varchar(30),ifsc varchar(11),balance int,primary key(bankacc)); 

insert into banktb values(9875461,'ICICI Bank','ICI00000078',7800000);
insert into banktb values(143441110,'Bank of India','BOI00000124',99663);
insert into banktb values(15478451,'Indian Bank','IB12457841K',7800000);
insert into banktb values(124578124,'Andhra Bank','AB65432450U',7800000);
insert into banktb values(658745124,'Allahabad Bank','ALB1452145H',7800000);
insert into banktb values(132458455,'Indian Bank','IB12451241K',7800000);
insert into banktb values(36578451,'Bank of Maharashtra','BOM1451244S',7800000);
insert into banktb values(1245174,'ICICI Bank','ICI00000078',7800000);
insert into banktb values(10002457,'Bank of India','BOI00000124',7800000);
insert into banktb values(4785415,'Bank of India','BOI00000124',7800000);
insert into banktb values(1234567,'ICICI Bank','ICI00000078',7800000);
insert into banktb values(1245451,'Allahabad Bank','ALB1452145H',7800000);
insert into banktb values(1245147,'Indian Overseas Bank','IOB4531451Y',7800000);
insert into banktb values(1000124,'Bank of India','BOI2451241P',78000);
insert into banktb values(1245741,'Indian Bank','IB12451241K',52000);

delete from comtb where comacc=75
delete from shopktb where sid=9



















