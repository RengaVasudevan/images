package taxcProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

public class ShowShopkDAO 
{
	static List<ShowShopkBean> ls=new ArrayList();
	static Connection con=null;
	   static ResultSet rs;
	  static  LoginBean lbean=new LoginBean();
		static Statement st=null;
		static PreparedStatement pst=null;
		public static List<ShowShopkBean> getAllShopkeeperDetails(ShowShopkBean sbean)
		{
			
			
			String sqlst="";
			
		    int comacc=0,bankacc=0;
			try
			{
				
				
			      con=ConnectionManager.getConnection();
				   st =con.createStatement();
			  
				   sqlst ="SELECT comacc,bankacc from shopktb WHERE sid ="+sbean.getSid();
					rs = st.executeQuery(sqlst);
					while(rs.next())
					{
						comacc=rs.getInt("comacc");
						bankacc=rs.getInt("bankacc");
				    }
					sbean.setComacc(comacc);
					sbean.setBankacc(bankacc);
					
					sqlst ="SELECT com1,com2,com3 from comtb WHERE comacc="+comacc;
					rs = st.executeQuery(sqlst);
					while(rs.next())
					{
					sbean.setCom1(rs.getInt("com1"));
					sbean.setCom2(rs.getInt("com2"));
					sbean.setCom3(rs.getInt("com3"));
					}
					
					sqlst ="SELECT bankname,ifsc,balance from banktb WHERE bankacc="+bankacc;
					rs = st.executeQuery(sqlst);
					while(rs.next())
					{
						sbean.setBankname(rs.getString("bankname"));
						sbean.setIfsc(rs.getString("ifsc"));
					sbean.setBal(rs.getInt("balance"));
					}
					
					sqlst ="SELECT * from salestb WHERE sid="+sbean.getSid();
					rs = st.executeQuery(sqlst);
					while(rs.next())
					{
ls.add(new ShowShopkBean(rs.getInt("sid"),rs.getString("comname"),rs.getInt("Quant"),rs.getString("act"),rs.getFloat("price"),rs.getFloat("tax_amount")));
					}
					
					
					
					
			}
			catch(Exception e)
			{
				
				
			}
			
			
			return ls;
			
		}
}
