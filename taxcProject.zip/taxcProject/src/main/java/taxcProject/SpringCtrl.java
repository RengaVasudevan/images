package taxcProject;

import java.util.*;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/taxc")
public class SpringCtrl 
{
	
	@Autowired
	GetAllSalesDaoImpl impl;
	
		@RequestMapping(value = "/getAllShopk" , method = RequestMethod.GET)
        public List<ViewShopkBean> getAllShopkeepers()
        {          
                    List<ViewShopkBean> searchlist=ViewShopkDAO.getAllShopkeepers();
                    return searchlist;
        }
		
		
		@RequestMapping(value="/insert",method=RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces={ MediaType.APPLICATION_JSON_VALUE})
        public int insertShopkeeper(@RequestBody RegisterBean rbean)
        {          
			
			return RegisterDAO.validateCredentials(rbean);
			
       }
		
		@RequestMapping(value = "/getAllSales" , method = RequestMethod.GET)
        public List<ViewAllSalesBean> getAllSales() throws Exception
        {          
                    List<ViewAllSalesBean> searchlist=impl.getAllTests();
                    for(ViewAllSalesBean b:searchlist)
                    {
                    	System.out.println(b.toString());
                    }
                    		return searchlist;
        }
		
		
		
	
}
