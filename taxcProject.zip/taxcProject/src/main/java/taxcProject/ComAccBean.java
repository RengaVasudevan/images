package taxcProject;


public class ComAccBean 
{
private String name,comtdy;
private int sid,quanc,qua,comacc,price,bankacc,bal,com1,com2,com3;

public int getCom1() {
	return com1;
}
public void setC1(int com1) {
	this.com1 = com1;
}
public int getCom2() {
	return com2;
}
public void setC2(int c2) {
	this.com2 = com2;
}
public int getCom3() {
	return com3;
}
public void setC3(int com3) {
	this.com3 = com3;
}
public ComAccBean()
{
	name="";
	comtdy="";
	sid=0;
	quanc=0;
	qua=0;
	comacc=0;
	price=0;
	bankacc=0;
	bal=0;
}
public ComAccBean(int com1,int com2,int com3)
{
	this.com1=com1;
    this.com2=com2;
    this.com3=com3;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getComtdy() {
	return comtdy;
}
public void setComtdy(String comtdy) {
	this.comtdy = comtdy;
}
public int getSid() {
	return sid;
	
}
public void setSid(int sid) {
	this.sid = sid;
}
public int getQuanc() {
	return quanc;
}
public void setQuanc(int quanc) {
	this.quanc = quanc;
}
public int getQua() {
	return qua;
}
public void setQua(int qua) {
	this.qua = qua;
}
public int getComacc() {
	return comacc;
}
public void setComacc(int comacc) {
	this.comacc = comacc;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getBankacc() {
	return bankacc;
}
public void setBankacc(int bankacc) {
	this.bankacc = bankacc;
}
public int getBal() {
	return bal;
}
public void setBal(int bal) {
	this.bal = bal;
}




}
