package taxcProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

public class ViewAllSalesDAO 
{
	
	static Connection con=null;
	   static ResultSet rs,rs1;
	  static  LoginBean lbean=new LoginBean();
		static Statement st=null;
		static PreparedStatement pst=null;
public static List<ViewAllSalesBean> getAllSales(ViewAllSalesBean vbean)
{
List<ViewAllSalesBean> ls=new ArrayList();
int i=0;
String sqlst=""; 
int sid=0,comac=0,bankacc=0;
String name="";
try
{
	
	
	
     con=ConnectionManager.getConnection();
	   st =con.createStatement();
   
  
    sqlst ="SELECT * from salestb";
	
	 rs = st.executeQuery(sqlst);
	 while(rs.next())
		{
		
ls.add(new ViewAllSalesBean(rs.getInt("sid"),rs.getString("comname"),rs.getInt("quant"),rs.getString("act"),rs.getFloat("price"),rs.getFloat("tax_amount")));
	    }
	
		
	 
		 
}
catch(Exception e)
{
	
	
}



return ls;


}
}
