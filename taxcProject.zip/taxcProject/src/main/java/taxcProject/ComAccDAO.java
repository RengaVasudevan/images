package taxcProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import org.apache.log4j.Logger;



public class ComAccDAO 
{
	final static Logger logger = Logger.getLogger(ComAccDAO.class);      
public static List<ComAccBean> viewCommodityAccount(ComAccBean tbean)
{
	 
	String sqlst,comtdy;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
    List <ComAccBean> ls =new ArrayList();
	int status=0,ch,sid=0,quanc=0,qua=0,comacc=0,price=0,bankacc=0,bal=0;
	try
	{
		
		
		con=ConnectionManager.getConnection();
		logger.info("Database Connected !!!");
		st =con.createStatement();
		sqlst ="SELECT name from shopktb WHERE sid="+tbean.getSid();
		ResultSet rs = st.executeQuery(sqlst);
		if(rs.next())
		{
		sqlst ="SELECT comacc from shopktb WHERE sid="+tbean.getSid();
		rs = st.executeQuery(sqlst);
		
		while(rs.next())
		{
	     comacc  = rs.getInt("comacc");
	    }
		sqlst ="SELECT * from comtb WHERE comacc="+comacc;
		 rs = st.executeQuery(sqlst);
		 System.out.println("Commacc"+"\t"+"com1"+"\t"+"com2"+"\t"+"com3");
		 
		while(rs.next())
		{
			
	        ls.add(new ComAccBean(rs.getInt("com1"),rs.getInt("com2"),rs.getInt("com3")));
	       
	    }
		 
		}
		
		
		}
		
		catch(SQLException e)
	{
		e.printStackTrace();
	} 
	
		
		finally
		{
		
		try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			
		}
	
	
	   return ls;
}
}
