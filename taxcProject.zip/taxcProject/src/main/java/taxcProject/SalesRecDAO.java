package taxcProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import org.apache.log4j.Logger;



public class SalesRecDAO 
{
	
	final static Logger logger = Logger.getLogger(SalesRecDAO.class);      
public static List<SalesRecBean> showSalesRecord(SalesRecBean tbean)
{
	String sqlst,comtdy;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
     List<SalesRecBean> ls=new ArrayList();
	int status=0,ch,sid=0,quanc=0,qua=0,comacc=0,price=0,bankacc=0,bal=0;
	
	try
	{ 
		con=ConnectionManager.getConnection();
		System.out.println("DB Connected !");
		st =con.createStatement();
		sqlst ="SELECT name from shopktb WHERE sid="+tbean.getSid();
		ResultSet rs = st.executeQuery(sqlst);
		if(rs.next())
		{
	sqlst ="SELECT * from salestb WHERE sid="+tbean.getSid();
	 rs = st.executeQuery(sqlst);
	 System.out.println("Shopkeyid"+"\t"+"ComName"+"\t\t"+"Quantity"+"\t"+"Action"+"\t\t"+"Price"+"\t"+"Tax_Collected");
	while(rs.next())
	{
      
      ls.add(new SalesRecBean(rs.getString("comname"),rs.getInt("quant"),rs.getString("act"),rs.getInt("price"),rs.getInt("tax_amount")));
      //rs.getInt("sid")+"\t\t"+rs.getString("comname")+"\t\t"+rs.getInt("quant")+"\t\t"+rs.getString("act")+"\t\t"+rs.getInt("price")+"\t\t"+rs.getInt("tax_amount"));
    }
	
		}
		else
		{
			logger.warn("\n�nter Existing/Correct Shopkeeper ID !");
		}
	}
	
	catch(SQLException e)
{
	e.printStackTrace();
} 
	
	
	finally
	{
	
	try 
	{
	con.close();
    } 
	catch (SQLException e) 
	{
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		
	
	
}
	return ls;
}
}
