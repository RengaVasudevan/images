package taxcProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ViewShopkDAO 
{

	static Connection con=null;
	   static ResultSet rs,rs1;
	  static  LoginBean lbean=new LoginBean();
		static Statement st=null;
		static PreparedStatement pst=null;
		
		public static List<ViewShopkBean> getAllShopkeepers()
		{
			List<ViewShopkBean> ls=new ArrayList();
			int i=0;
			String sqlst=""; 
		    int sid=0,comac=0,bankacc=0;
		    String name="";
			try
			{
				
				
				
			     con=ConnectionManager.getConnection();
				   st =con.createStatement();
			   
		      
		        sqlst ="SELECT * from shopktb order by sid";
				
				 rs = st.executeQuery(sqlst);
				 while(rs.next())
					{
					
		    ls.add(new ViewShopkBean(rs.getInt("sid"),rs.getString("name"),rs.getInt("comacc"),rs.getInt("bankacc")));
				    }
				
					
				 
					 
		}
		catch(Exception e)
			{
				
				
			}
			
			
			
		return ls;
		}
		
}
