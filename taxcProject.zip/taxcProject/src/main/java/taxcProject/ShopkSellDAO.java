package taxcProject;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

public class ShopkSellDAO 
{
	
	static Connection con=null;
	   static ResultSet rs;
	  static  ShopkSellBean sbean=new ShopkSellBean();
		static Statement st=null;
		final static Logger logger = Logger.getLogger(ShopkSellDAO.class);      
public static int shopkSells(ShopkSellBean tbean)
{
	int i=0,price,comacc=0,bankacc=0,quanc=0,bal=0;
	
	String sqlst="";
	try
	{
		con=ConnectionManager.getConnection();
		st =con.createStatement();
		sqlst ="SELECT name from shopktb WHERE sid="+tbean.getSid();
		ResultSet rs = st.executeQuery(sqlst);
		
	    price=(tbean.getQua())*10;
		System.out.println("\nCalculated Price:"+price);
		
		con=ConnectionManager.getConnection();
		System.out.println("DB Connected !");
	 st =con.createStatement();
	sqlst ="SELECT comacc,bankacc from shopktb WHERE sid="+tbean.getSid();
	rs = st.executeQuery(sqlst);
	while(rs.next())
	{
     comacc  = rs.getInt("comacc");
     bankacc=rs.getInt("bankacc");
    }
	//System.out.println(comacc+bankacc);
	sqlst ="SELECT "+tbean.getComtdy()+ " from comtb WHERE comacc="+comacc;
     rs = st.executeQuery(sqlst);
	while(rs.next())
	{
     quanc  = rs.getInt(tbean.getComtdy());
    }
	
	
	System.out.println("\nInspection going on.... ");
	if(quanc>=tbean.getQua()&&tbean.getQua()>0)
	{
	sqlst="";
	sqlst ="SELECT "+tbean.getComtdy()+ " from comtb WHERE comacc="+comacc;
     rs = st.executeQuery(sqlst);
	while(rs.next())
	{
     quanc  = rs.getInt(tbean.getComtdy());
    }
	
	sqlst ="SELECT balance from banktb WHERE bankacc="+bankacc;
	 rs = st.executeQuery(sqlst);
	while(rs.next())
	{
     bal = rs.getInt("balance");
    }
	sqlst="";
	sqlst = "UPDATE comtb " +"SET "+tbean.getComtdy()+" = "+ (quanc-tbean.getQua())+" WHERE comacc="+comacc;
    st.executeUpdate(sqlst);
    sqlst="";
	sqlst = "INSERT INTO salestb VALUES("+tbean.getSid()+",'"+tbean.getComtdy()+"',"+tbean.getQua()+",'Sell',"+price+","+((price*10)/100)+")";
    st.executeUpdate(sqlst);
    logger.info("\nCollecting Tax....\n");
    sqlst = "UPDATE banktb SET balance = "+ (bal+(price*90/100))+" WHERE bankacc="+bankacc;
    st.executeUpdate(sqlst);
    logger.info("\nTransaction commited !\n");
    logger.info("Commodity "+tbean.getComtdy()+" of quantity "+tbean.getQua()+" has been sold succesfully by shopkeeper "+tbean.getSid());
	i=1;
	}
	else
	{
		
		i=2;
		logger.warn("Commodity out of stock !");
	}
		
		
		
	}

	catch(SQLException e)
{
		System.out.println(e.getMessage());
} 
	
	
	finally
	{
	
	try {
	con.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		
	}
return i;
}
}
