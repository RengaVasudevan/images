package taxcProject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Random;

import org.apache.log4j.Logger;


public class RegisterDAO 
{
	static Connection con=null;
	   static ResultSet rs,rs1;
	 
		static Statement st=null;
		static PreparedStatement pst=null;
		final static Logger logger = Logger.getLogger(RegisterDAO.class);      
		
		 
			
public static int validateCredentials(RegisterBean rbean)
{
	
	String sqlst=""; 
    int status=0,sid=0,comacc=0;
	try
	{
		
		
	      con=ConnectionManager.getConnection();
		   st =con.createStatement();
	  
		   sqlst ="SELECT name from shopktb WHERE bankacc="+rbean.getBankacc();
			rs = st.executeQuery(sqlst);
			if(!(rs.next()))
			{
				rs=null;
        Random rg,rg2;
        rg= new Random();
        
		 while(true)
		 {
		      
			  
				sid=rg.nextInt(10000);
				sqlst ="SELECT name from shopktb WHERE sid="+sid;
				rs = st.executeQuery(sqlst);
				if(!(rs.next()))
				{
					 rbean.setSid(sid);
					break;
				}
		    }
		 rg2=new Random();
		 while(true)
		 {
		      
		      
				comacc=rg2.nextInt(10000);
				sqlst ="SELECT name from shopktb WHERE comacc="+comacc;
				rs = st.executeQuery(sqlst);
				if(!(rs.next()))
				{
					rbean.setComacc(comacc);
					break;
				}
		    }
		 String email="";
		   email=rbean.getName().toLowerCase();
		   email=email.replaceAll("\\s+","");
			email+=rbean.getSid()+"@taxc.co.in";
		 sqlst="insert into shopktb values(?,?,?,?,?)";
			pst=con.prepareStatement(sqlst);
			pst.setInt(1, rbean.getSid());
			pst.setString(2, rbean.getName());
			
			pst.setInt(3, rbean.getComacc());
			pst.setInt(4, rbean.getBankacc());
			pst.setString(5, email);
			rbean.setEmail(email);
			if(pst.executeUpdate()==1)
			{
				System.out.println("shopk ins");
				status+=1;
			}
			pst=null;
			
			sqlst="insert into comtb values(?,?,?,?)";
			pst=con.prepareStatement(sqlst);
			pst.setInt(1,rbean.getComacc());
			pst.setInt(2, 0);
			
			pst.setInt(3,0);
			pst.setInt(4,0);
			if(pst.executeUpdate()==1)
			{
				status+=1;
				System.out.println("com ins");
			}
			pst=null;
			System.out.println("bn "+rbean.getBankname());
			System.out.println("if "+rbean.getIfsc());
			System.out.println("bal "+rbean.getBal());
			sqlst="insert into banktb values(?,?,?,?)";
			pst=con.prepareStatement(sqlst);
			pst.setInt(1, rbean.getBankacc());
			
			pst.setString(2,rbean.getBankname());
			pst.setString(3,rbean.getIfsc());
			pst.setInt(4,rbean.getBal());
			
			if(pst.executeUpdate()==1)
			{
				status+=1;
				System.out.println("bank ins");
			}
			pst=null;
			
			 
			
 
			 
} 
			else
			{
				status=1;
				
			}
	}
	catch(Exception e)
	{
		
		
	}
	System.out.println(status);
	if(status==3)
		logger.info("Shopkeeper data inserted successfully!");
	else if(status==1)
		logger.error("Bank account is already registered!");
	
	
	
	
	return status;
	
}



public static void giveShopkInfo(RegisterBean lbean)
{
	
	String sqlst=""; 
    
	try
	{
		
		
		
	      con=ConnectionManager.getConnection();
		   st =con.createStatement();
	   
      
        sqlst ="SELECT sid,name,comacc,email from shopktb WHERE bankacc="+lbean.getBankacc();
		
		 rs = st.executeQuery(sqlst);
		 while(rs.next())
			{
			  lbean.setSid(rs.getInt("sid"));
			  lbean.setName(rs.getString("name"));
			  lbean.setComacc(rs.getInt("comacc"));
		      lbean.setEmail(rs.getString("email"));
		     }
		
		 
			
				sqlst ="SELECT balance from banktb WHERE bankacc="+lbean.getBankacc();
				 rs = st.executeQuery(sqlst);
				while(rs.next())
				{
			     lbean.setBal(rs.getInt("balance"));
			    }
				
			
	   
	
}
catch(Exception e)
	{
		
		
	}
	
	


}


}





















