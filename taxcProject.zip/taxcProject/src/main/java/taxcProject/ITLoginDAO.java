package taxcProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;

public class ITLoginDAO 
{
	static Connection con=null;
	   static ResultSet rs,rs1;
	  static  LoginBean lbean=new LoginBean();
		static Statement st=null;
		static PreparedStatement pst=null;
		final static Logger logger = Logger.getLogger(ITLoginDAO.class);      
public static int validateOfl(ITLoginBean ibean)
{
	String pass="",id,sqlst,name="";
	
int i=0;
try
{
con=ConnectionManager.getConnection();
st =con.createStatement();


sqlst ="SELECT name,pas from ittb WHERE dptid="+ibean.getId();

rs = st.executeQuery(sqlst);
while(rs.next())
{
name=rs.getString("name");	
pass=rs.getString("pas");	
}

if(pass!="")
{
if(pass.equals(ibean.getPass()))
{
	ibean.setName(name);
	i=1;	
}
else
	i=2;
}
else
{
i=3;	
}

}
catch(Exception e)
{
	logger.warn("Error occured");
}

return i;
}
}
