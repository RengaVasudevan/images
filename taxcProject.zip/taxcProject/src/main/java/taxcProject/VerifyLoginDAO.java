package taxcProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class VerifyLoginDAO 

{
	static Connection con=null;
	   static ResultSet rs,rs1;

		static Statement st=null;
		static PreparedStatement pst=null;
		
		public static void setShopkDetails(VerifyLoginBean lbean)
		{
			
			String sqlst=""; 
		    try
			{
				
				
				
			     con=ConnectionManager.getConnection();
				   st =con.createStatement();
			   
		      
		        sqlst ="SELECT name,comacc,bankacc from shopktb WHERE sid="+lbean.getSid();
				
				 rs = st.executeQuery(sqlst);
				 while(rs.next())
					{
					
					  lbean.setName(rs.getString("name"));
				      lbean.setComacc(rs.getInt("comacc"));
				      lbean.setBankacc(rs.getInt("bankacc"));
				     
				    }
				
				      
						sqlst ="SELECT balance from banktb WHERE bankacc="+lbean.getBankacc();
						 rs = st.executeQuery(sqlst);
						while(rs.next())
						{
					     lbean.setBal(rs.getInt("balance"));
					    }
						
			
		}
		catch(Exception e)
			{
				
				
			}
			
			
		}
		
}
