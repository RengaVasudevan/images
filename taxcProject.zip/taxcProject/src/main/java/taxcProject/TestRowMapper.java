package taxcProject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;



public class TestRowMapper implements RowMapper<ViewAllSalesBean> {

	public ViewAllSalesBean mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		ViewAllSalesBean testObj =new ViewAllSalesBean();
		testObj.setSid(rs.getInt(1));
		testObj.setComname(rs.getString(2));
		
		testObj.setQua(rs.getInt(3));
		testObj.setAct(rs.getString(4));
		testObj.setPrice(rs.getFloat(5));
		testObj.setTax(rs.getFloat(6));
		
		return testObj;
	}

}

