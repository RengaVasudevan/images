package taxcProject;


public class ShopkBuyBean 
{
private String name,comtdy;
private int sid,quanc,qua,comacc,price,bankacc,bal;

public ShopkBuyBean()
{
	name="";
	comtdy="";
	sid=0;
	quanc=0;
	qua=0;
	comacc=0;
	price=0;
	bankacc=0;
	bal=0;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getComtdy() {
	return comtdy;
}
public void setComtdy(String comtdy) {
	this.comtdy = comtdy;
}
public int getSid() {
	return sid;
	
}
public void setSid(int sid) {
	this.sid = sid;
}
public int getQuanc() {
	return quanc;
}
public void setQuanc(int quanc) {
	this.quanc = quanc;
}
public int getQua() {
	return qua;
}
public void setQua(int qua) {
	this.qua = qua;
}
public int getComacc() {
	return comacc;
}
public void setComacc(int comacc) {
	this.comacc = comacc;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getBankacc() {
	return bankacc;
}
public void setBankacc(int bankacc) {
	this.bankacc = bankacc;
}
public int getBal() {
	return bal;
}
public void setBal(int bal) {
	this.bal = bal;
}




}
