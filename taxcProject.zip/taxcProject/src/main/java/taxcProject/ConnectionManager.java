package taxcProject;



import java.sql.*;
import java.util.*;
import org.apache.log4j.Logger;

public class ConnectionManager {

   static Connection con;
   static String url;
   final static Logger logger = Logger.getLogger(ConnectionManager.class);      
   public static Connection getConnection()
   {
	   
      try
      {
         
         

         Class.forName("org.apache.derby.jdbc.ClientDriver");
         
                    	
            try {
            	
            	con=DriverManager.getConnection("jdbc:derby://172.24.18.76:1527/XBBNHCN","user","pwd");
            	logger.info("Database Connected !!!");
            	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
             								
         
              
         
         
      }

      catch(ClassNotFoundException e)
      {
         System.out.println(e);
      }

   return con;
}
}
